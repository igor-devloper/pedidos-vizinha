import { normalizeSaboresList } from "@/lib/sabores";
import { normalizeDiscountPercent } from "@/lib/descontos";

export const PRODUCT_CATEGORIES = ["CENTO", "LANCHONETE", "COMBO"] as const;

export type ProductCategory = (typeof PRODUCT_CATEGORIES)[number];

export type ComboItem = {
  nome: string;
  quantidade: number;
};

export const PRODUCT_CATEGORY_LABEL: Record<ProductCategory, string> = {
  CENTO: "Cento",
  LANCHONETE: "Lanchonete",
  COMBO: "Combo",
};

export type ProdutoPayloadInput = {
  nome?: string;
  descricao?: string;
  preco?: number | string;
  precoConfeiteira?: number | string | null;
  quantidadeMinimaConfeiteira?: number | string | null;
  ativoConfeiteira?: boolean;
  imagemBase64?: string;
  categoria?: ProductCategory;
  productTypeId?: string | null;
  totalUnidades?: number | string;
  maxTiposSalgado?: number | string;
  permitePagamentoParcial?: boolean;
  saboresSugeridos?: string[];
  comboItens?: ComboItem[] | null;
  emPromocao?: boolean;
  descontoPercentual?: number | string;
  ativo?: boolean;
  antecedenciaMinimaHoras?: number | string | null;
  precisaSelecaoDeTipos?: boolean;
};

function normalizeCategoria(value: string | undefined): ProductCategory {
  return PRODUCT_CATEGORIES.includes(value as ProductCategory)
    ? (value as ProductCategory)
    : "CENTO";
}

export function normalizeComboItens(value: unknown): ComboItem[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .map((item) => {
      if (!item || typeof item !== "object") {
        return null;
      }

      const nome =
        "nome" in item && typeof item.nome === "string" ? item.nome.trim() : "";
      const quantidade =
        "quantidade" in item ? Number(item.quantidade) : Number.NaN;

      if (!nome || !Number.isInteger(quantidade) || quantidade <= 0) {
        return null;
      }

      return { nome, quantidade };
    })
    .filter((item): item is ComboItem => Boolean(item));
}

export function validateProdutoPayload(body: ProdutoPayloadInput) {
  const nome = body.nome?.trim() || "";
  const descricao = body.descricao?.trim() || "";
  const preco = Number(body.preco);
  const precoConfeiteira = body.precoConfeiteira === null || body.precoConfeiteira === "" || body.precoConfeiteira === undefined ? null : Number(body.precoConfeiteira);
  const quantidadeMinimaConfeiteira = body.quantidadeMinimaConfeiteira === null || body.quantidadeMinimaConfeiteira === "" || body.quantidadeMinimaConfeiteira === undefined ? null : Number(body.quantidadeMinimaConfeiteira);
  const ativoConfeiteira = body.ativoConfeiteira ?? false;
  const imagemBase64 = body.imagemBase64?.trim() || "";
  const categoria = normalizeCategoria(body.categoria);
  const productTypeId = body.productTypeId?.trim() || null;
  const permitePagamentoParcial = body.permitePagamentoParcial ?? true;
  const saboresSugeridos = normalizeSaboresList(body.saboresSugeridos);
  const comboItens = normalizeComboItens(body.comboItens);
  const emPromocao = body.emPromocao ?? false;
  const descontoPercentual = normalizeDiscountPercent(body.descontoPercentual);
  const ativo = body.ativo ?? true;
  const antecedenciaMinimaHoras = body.antecedenciaMinimaHoras === null || body.antecedenciaMinimaHoras === "" || body.antecedenciaMinimaHoras === undefined ? null : Number(body.antecedenciaMinimaHoras);
  const precisaSelecaoDeTipos = body.precisaSelecaoDeTipos ?? true;

  if (antecedenciaMinimaHoras !== null && (!Number.isInteger(antecedenciaMinimaHoras) || antecedenciaMinimaHoras < 0)) {
    return { error: "Informe uma antecedência mínima válida." };
  }

  if (!nome) {
    return { error: "Informe o nome do produto." };
  }

  if (!descricao) {
    return { error: "Informe a descrição do produto." };
  }

  if (!Number.isFinite(preco) || preco <= 0) {
    return { error: "Informe um valor válido." };
  }
  if (ativoConfeiteira && (!Number.isFinite(precoConfeiteira) || precoConfeiteira! <= 0)) return { error: "Informe o preço para confeiteira." };
  if (quantidadeMinimaConfeiteira !== null && (!Number.isInteger(quantidadeMinimaConfeiteira) || quantidadeMinimaConfeiteira <= 0)) return { error: "Informe uma quantidade mínima válida para confeiteira." };

  if (emPromocao && descontoPercentual <= 0) {
    return { error: "Informe o percentual de desconto da promoção." };
  }

  if (!imagemBase64.startsWith("data:image/")) {
    return { error: "Envie uma imagem válida para o produto." };
  }

  if (imagemBase64.length > 2_500_000) {
    return { error: "A imagem ficou muito grande. Tente um arquivo menor." };
  }

  if (categoria === "COMBO") {
    if (comboItens.length === 0) {
      return { error: "Cadastre ao menos um item fixo para o combo." };
    }

    const totalUnidades = comboItens.reduce((sum, item) => sum + item.quantidade, 0);
    const maxTiposSalgado = comboItens.length;

    return {
      data: {
        nome,
        descricao,
        preco: Number(preco.toFixed(2)),
        precoConfeiteira: precoConfeiteira === null ? null : Number(precoConfeiteira.toFixed(2)),
        quantidadeMinimaConfeiteira,
        ativoConfeiteira,
        imagemBase64,
        categoria,
        productTypeId,
        totalUnidades,
        maxTiposSalgado,
        permitePagamentoParcial,
        saboresSugeridos: comboItens.map((item) => item.nome),
        comboItens,
        emPromocao,
        descontoPercentual,
        ativo,
        antecedenciaMinimaHoras,
        precisaSelecaoDeTipos,
      },
    };
  }

  const totalUnidades = precisaSelecaoDeTipos ? Number(body.totalUnidades) : 1;
  const maxTiposSalgado = precisaSelecaoDeTipos ? Number(body.maxTiposSalgado) : 1;

  if (!Number.isInteger(totalUnidades) || totalUnidades <= 0) {
    return { error: "Informe o total de unidades do produto." };
  }

  if (!Number.isInteger(maxTiposSalgado) || maxTiposSalgado <= 0) {
    return { error: "Informe o limite de tipos permitidos." };
  }

  return {
    data: {
      nome,
      descricao,
      preco: Number(preco.toFixed(2)),
      precoConfeiteira: precoConfeiteira === null ? null : Number(precoConfeiteira.toFixed(2)),
      quantidadeMinimaConfeiteira,
      ativoConfeiteira,
      imagemBase64,
      categoria,
      productTypeId,
      totalUnidades,
      maxTiposSalgado,
      permitePagamentoParcial,
      saboresSugeridos: precisaSelecaoDeTipos ? saboresSugeridos : [],
      comboItens: [],
      emPromocao,
      descontoPercentual,
      ativo,
      antecedenciaMinimaHoras,
      precisaSelecaoDeTipos,
    },
  };
}

export function getProdutoComboItens(produto: { comboItens?: unknown }): ComboItem[] {
  return normalizeComboItens(produto.comboItens);
}

export function isComboProduto(produto: { categoria?: unknown; comboItens?: unknown }): boolean {
  return produto.categoria === "COMBO" && getProdutoComboItens(produto).length > 0;
}
